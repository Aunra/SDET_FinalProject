package com.automation.stepdefination;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.automation.assertions.Compare;
import com.automation.base.DriverInstance;
import com.automation.utility.ConfigReader;

import cucumber.api.java.en.*;

public class StepDefination extends DriverInstance{
	
	//WebDriver driver=null;
@Given("^User is on registration page$")
public void user_is_on_registration_page() throws Throwable {
	/*System.setProperty("webdriver.chrome.driver","Driver/chromedriver.exe");
	driver=new ChromeDriver();
  driver.get("https://www.gillette.co.in/en-in/createprofilepage");
 System.out.println(ConfigReader.readProjectConfiguration("ApplicationURL"));
  driver.manage().window().maximize();
  driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);*/
	DriverInstance.startDriverInstance();
	takeSnapShot(getDriver(), "Screenshots/Screen.png");
}

@When("^User enter Firstname$")
public void user_enter_Firstname() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("firstname_id"))).sendKeys("Auto"); 
	takeSnapShot(getDriver(), "Screenshots/Screen1.png");
   
}

@When("^User enter Lastname$")
public void user_enter_Lastname() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("Lastname_id"))).sendKeys("mation");    
	takeSnapShot(getDriver(), "Screenshots/Screen2.png");
}

@When("^User enter Email$")
public void user_enter_Email() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("Email_id"))).sendKeys("Auto88mation2@gmail.com");     
	takeSnapShot(getDriver(), "Screenshots/Screen3.png");
}

@When("^User enter Password$")
public void user_enter_Password() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("Password_id"))).sendKeys("Akhil@123"); 
	takeSnapShot(getDriver(), "Screenshots/Screen4.png");
}

@When("^User enter confirm Password$")
public void user_enter_confirm_Password() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("ConfirmPassword_id"))).sendKeys("Akhil@123");
	takeSnapShot(getDriver(), "Screenshots/Screen5.png");
}

@When("^User enter Birthdate month$")
public void user_enter_Birthdate_month() throws Throwable {
	Select Month = new Select(getDriver().findElement(By.id(ConfigReader.readProjectlocator("Birthdatemonth_id"))));
	 Month.selectByValue("10"); 
	 takeSnapShot(getDriver(), "Screenshots/Screen6.png");
}

@When("^User enter Birthdate Year$")
public void user_enter_Birthdate_Year() throws Throwable {
	Select Year = new Select(getDriver().findElement(By.id(ConfigReader.readProjectlocator("Birthyear_id"))));
	 Year.selectByValue("1988");
	 takeSnapShot(getDriver(), "Screenshots/Screen7.png");
}

@When("^User enter Zipcode$")
public void user_enter_Zipcode() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("zipcode_id"))).sendKeys("201105");
	takeSnapShot(getDriver(), "Screenshots/Screen8.png");
}

@When("^User click on checkbox$")
public void user_click_on_checkbox() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("checkbox_id"))).click();
	takeSnapShot(getDriver(), "Screenshots/Screen9.png");
}

@When("^User click Create Your Profile$")
public void user_click_Create_Your_Profile() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("CreateProfileButton_id"))).click();  
	getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);  
}

@Then("^Account should be created$")
public void account_should_be_created() throws Throwable {
	  boolean result= false;
		if (getDriver().getPageSource().contains("YOUR REGISTRATION IS COMPLETE")) {
			  result=true;
			  System.out.println("Registation complete");
			  getDriver().close();
			  getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
			  takeSnapShot(getDriver(), "Screenshots/Screen10.png");
		  }  
}

@Given("^User is on login page$")
public void user_is_on_login_page() throws Throwable {
	
		 getDriver().get(ConfigReader.readProjectConfiguration("ApplicationURL1"));
		  getDriver().manage().window().maximize();
			 getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		
}

@When("^User enter email$")
public void user_enter_email() throws Throwable {
	testDataGenerator();
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("login_email_id"))).sendKeys("Auto88mation@gmail.com"); 
	getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("login_password_xpath"))).sendKeys("Akhil@123"); 
	takeSnapShot(getDriver(), "Screenshots/Screen11.png");
}

@When("^User click on sign-in$")
public void user_click_on_sign_in() throws Throwable {
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("login_button_xpath"))).click();; 
}

@Then("^User should be signed in$")
public void user_should_be_signed_in() throws Throwable {
	 /* boolean result= false;
		if (getDriver().getPageSource().contains("YOUR PROFILE")) {
			  result=true;*/
			  
			  Compare.validateLoginsuccess(getDriver(), "YOUR PROFILE");
			  System.out.println("Sign-in Successfully");
			  takeSnapShot(getDriver(), "Screenshots/Screen12.png");
			  getDriver().close();
}

@Given("^User is on gillete login page$")
public void user_is_on_gillete_login_page() throws Throwable {
	
		 getDriver().get(ConfigReader.readProjectConfiguration("ApplicationURL1"));
		  getDriver().manage().window().maximize();
			 getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		
}

@When("^user click on forgot password link$")
public void user_click_on_forgot_password_link() throws Throwable {
getDriver().findElement(By.id(ConfigReader.readProjectlocator("ForgotPassword_link_id"))).click();
getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
getDriver().findElement(By.id(ConfigReader.readProjectlocator("login_email_id"))).sendKeys("Auto88mation@gmail.com"); 
}

@When("^click on create a new password$")
public void click_on_create_a_new_password() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("CreatenewpasswordButton_id"))).click(); 
}

@When("^close the window$")
public void close_the_window() throws Throwable {
	  getDriver().close();
}

@When("^Open Gmail$")
public void open_Gmail() throws Throwable {
	 getDriver().get(ConfigReader.readProjectConfiguration("ApplicationURL2"));
	  getDriver().manage().window().maximize();
		 getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
}

@When("^enter username$")
public void enter_username() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("Gmail_Email_id"))).sendKeys("Auto88mation@gmail.com"); 
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("Gmail_nextbutton_xpath"))).click();
}

@When("^enter password$")
public void enter_password() throws Throwable {
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("Gmail_Password_xpath"))).sendKeys("Auto88mation@gmail.com"); 
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("Gmail_nextbutton1_xpath"))).click();
}

@When("^search for first email from gillete$")
public void search_for_first_email_from_gillete() throws Throwable {
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("FirstEmail_xpath"))).click(); 
}


@When("^click on the reset password link$")
public void click_on_the_reset_password_link() throws Throwable {
	getDriver().findElement(By.xpath(ConfigReader.readProjectlocator("Resetpassword_link"))).click();
	getDriver().close();
}

@When("^Enter new password$")
public void enter_new_password() throws Throwable {
	getDriver().get(ConfigReader.readProjectConfiguration("ApplicationURL1"));
	  getDriver().manage().window().maximize();
		 getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("Newpassword_id"))).sendKeys("Akhil@123");  
	takeSnapShot(getDriver(), "Screenshots/Screen13.png");
}

@When("^confirm new password$")
public void confirm_new_password() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("ConfirmNewPassword_id"))).sendKeys("Akhil@123");
}

@When("^Click on create new password$")
public void click_on_create_new_password() throws Throwable {
	getDriver().findElement(By.id(ConfigReader.readProjectlocator("CreatenewPassword_button_id"))).click();
}

@Then("^User should be able to see sign-in screen$")
public void user_should_be_able_to_see_sign_in_screen() throws Throwable {
	  /*boolean result= false;
			if (getDriver().getPageSource().contains("SIGN IN")) {
				  result=true;
				  System.out.println("Sign In");
				  getDriver().close();
				  getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);*/
	Compare.validateLoginsuccess(getDriver(), "SIGN IN");
	takeSnapShot(getDriver(), "Screenshots/Screen14.png");
			  
}
public void takeSnapShot(WebDriver driver,String fileWithPath) throws Exception{


     TakesScreenshot scrShot =((TakesScreenshot)driver);
     File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
     File DestFile=new File(fileWithPath);
     FileUtils.copyFile(SrcFile, DestFile);

}
public Object[][] testDataGenerator() throws Exception
{
	FileInputStream file=new FileInputStream("TestData/DataFromExcel.xlsx");
	XSSFWorkbook workbook= new XSSFWorkbook(file);
	XSSFSheet loginSheeet=workbook.getSheet("Login");
	int numberofrows=loginSheeet.getPhysicalNumberOfRows();
	Object [][] testdata=new Object[numberofrows][2];
	
	for(int i=0;i<numberofrows;i++) {
		XSSFRow row=loginSheeet.getRow(i);
		XSSFCell username=row.getCell(0);
		XSSFCell password=row.getCell(1);
		testdata[i][0]=username.getStringCellValue();
		testdata[i][1]=password.getStringCellValue();		
				
			}
	return testdata;
}

}
