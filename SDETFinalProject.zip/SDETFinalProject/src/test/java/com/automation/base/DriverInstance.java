package com.automation.base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.automation.utility.ConfigReader;

public class DriverInstance {
private static WebDriver driver =null;

public static void startDriverInstance() throws IOException {
	if(ConfigReader.readProjectConfiguration("Browsername").equalsIgnoreCase("Chrome")){
		System.setProperty("webdriver.chrome.driver","Driver/chromedriver.exe");
		setDriver(new ChromeDriver());
	}
	else if(ConfigReader.readProjectConfiguration("Browsername").equalsIgnoreCase("FireFox")){
		
		System.setProperty("webdriver.gecko.driver","Driver/geckodriver.exe");
		setDriver(new FirefoxDriver());
	}
	getDriver().get(ConfigReader.readProjectConfiguration("ApplicationURL"));
	getDriver().manage().window().maximize();
	  getDriver().manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
}
 public static WebDriver getDriverInstance() throws IOException {
	 if (getDriver()!=null) {
		 return getDriver();
	 }
	 else {
		 DriverInstance.startDriverInstance();
		 return getDriver();
	 }
 }

 public static void setDriverInstancenull() {
	 setDriver(null);
 }
public static WebDriver getDriver() {
	return driver;
}
public static void setDriver(WebDriver driver) {
	DriverInstance.driver = driver;
}
}
