package com.automation.assertions;

import org.openqa.selenium.WebDriver;

import com.automation.base.DriverInstance;

public class Compare extends DriverInstance {

	public static boolean validatePageURL(WebDriver driver, String expURL) {
		boolean flag=false;
		if (driver.getCurrentUrl().equalsIgnoreCase(expURL)){
			flag=true;
		}
		return flag;
		}
	public static boolean validateRegistrationcomplete(WebDriver driver, String expval) {
		boolean flag=false;
		if (driver.getPageSource().contains(expval)){
			flag=true;
		}
		return flag;
		}
	public static boolean validateLoginsuccess(WebDriver driver, String expval) {
		boolean flag=false;
		if (driver.getPageSource().contains(expval)){
			flag=true;
		}
		return flag;
		}
}
